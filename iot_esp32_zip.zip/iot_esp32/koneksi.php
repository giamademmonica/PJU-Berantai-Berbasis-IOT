<?php
$host = "localhost";
$user = "root";
$pass = ""; // Laragon default kosong
$db   = "iot_project"; 

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>